var port = 3000;

module.exports = {
  	db: 'mongodb://jhong:jhong@ds055525.mongolab.com:55545/heroku_sf66wt12',
  	port: port
  	// db: 'mongodb://localhost/songs'
}