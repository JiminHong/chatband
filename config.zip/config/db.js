var config = require('./config'),
	mongoose = require('mongoose');

module.exports = {
  db: 'mongodb://jhong:jhong@ds055525.mongolab.com:55545/heroku_sf66wt12'
  // require('../app/models/songs.server.model.js');

};